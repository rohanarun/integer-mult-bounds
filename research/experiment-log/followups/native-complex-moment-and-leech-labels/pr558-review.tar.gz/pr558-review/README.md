# Independent PR558 replay and complex recurrence carryover

**Full independent replay PASS.** PR558 at head060b137c8a6f9d73fd7864c7f8cf2736d6441774 reproduces conditional kappa0.001592517889315014 and complex saving b0.001595058047790616770328.

Source: https://github.com/CrocSwap/integer-mult-bounds/pull/558

## Acquisition and execution

158 source/dependency/validation/workflow files were acquired or reused only after exact Git-blob verification. ACQUISITION.json lists their Git blob identities, SHA-256 hashes and sizes. PR558.json and TREE.json retain source metadata. Source files were rechecked after the replay and remain unchanged.

The full verifier ran under Python3.14 with NumPy, assertions enabled, PYTHONDONTWRITEBYTECODE=1 and PYTHONINTMAXSTRDIGITS=0, into the fresh replay314 directory. It completed in126.92seconds with exit0. Exact command and environment are in REPLAY-COMMAND.json; logs and every stage receipt are retained. It recompiles all2,929 directed phase edges, which accounts for most runtime.

The replay reconstructs the pinned PR552 source, promotes eight pivots, verifies all728 formal columns in both orientations and arbitrary dirty helper restoration, reconstructs both reflected paid ledgers and normalized wrappers, recompiles224 endpoint adapters, then rebuilds the actual whole-owner controller and finite invoice. It checks the original44 and new8 scalar omissions,11 native controls,7 owner corruptions,13 malformed assembly inputs, both moment endpoints, seven bootstrap levels and47 strict outer constraints. All passed. The unchanged bit supplier remains a cited conditional PR543 dependency, not a fresh bit-circuit rebuild.

## Fresh admitted artifacts for composition

Use these actual reconstructed inputs, not the supplied author receipts:

- replay314/complex-global/audit/OWNERS-AND-PROFILE.json
- replay314/complex-global/audit/PREFIX-AND-INVOICE.json
- replay314/complex-global/audit/ASYNC-AUDIT.json
- replay314/complex-global/hosted/HOSTED.json
- replay314/ASSEMBLY.json and ASSEMBLY-CONTROLS.json

The admitted global profile is `{1:166880,2:30528,3:35779,4:13824,5:4032,6:4032,7:208,8:576,39:1,48:1660}`, live stock7168, physical stock7682 and rank deficit2560. The raw promoted word SHA-256 is375bd23001cd805707968005a9342827d5464e3f8e3a754197b31c46fc3f63c2.

REPLAY-COMPARISON.json records each selected artifact hash and whether its bytes match the author's Python3.14 receipt. RESULT matches the author result exactly apart from runtime. This review does not assert byte equality for timing-dependent artifacts.

## Applicability of the zero-complex-surcharge argument

The new package still prices **both** suppliers with `bad=True` and adds32*m^2 fallback children per ideal edge at fraction10^-16 in the second engine. See source/research/complex-rank5-pivots8/code/assemble.py.

COMPILER-LINEAGE.json verifies byte identity of seven critical emitter, auditor, wrapper, Clifford and invoice modules with the PR552 modules examined in the separate complex552-fallback-independent review. PR558 changes entrance/kernel frames and helper widths, reorders commuting kernel shears, and repacks the whole-owner schedule. The full fresh replay admits those changes. They introduce no q-adic good/bad selector: all actual charts are exact orthogonal maps, recursive children are explicitly counted, and finite group transport remains a right-translation bijection.

Therefore the prior conditional proof assessment applies to this fresh provider: its complex recurrence can use the exact child-profile moment without the additional bit-style bad-class surcharge, under the same retained exact complex compiler/all-size/precision/tape/analytic interfaces. Keep the bit surcharge and all finite router, adapter, row, prefix and precision charges. This review does not itself calculate or publish the resulting improved kappa; the parent owns that exact numerical composition and publication.

## Scope

This confirms the finite witness at the pinned head and its source-compatible complex recurrence argument. It is not an unconditional multiplication theorem, a fresh proof of all-size interfaces, a practical speedup, or a new bit admission. No upstream PR or source was edited and no publication was performed by this worker. All files and logs remain on the mounted SSD.
